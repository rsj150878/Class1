<?php
require 'inc/tools.php';
?>


<!DOCTYPE html>
<html lang="en">

<head>
<?php include'head.php'; ?>

</head>

<body class="p-3 m-0 border-0 bd-example m-0 border-0">
  <?php include('nav.php'); ?>
  <div class="container mt-5">
      
      <h4>Herzlich willkommen!</h4>
      <p class="mb-1">
                Wir freuen uns sehr über Ihren Besuch!
                Sie finden hier alle Informationen zu unserem Hotel und haben auch die Möglichkeit, eine Reservierung für einen Besuch bei uns vorzunehmen!
            </p>
            <p class="mb-1">
              Das Team freut sich jetzt schon über Ihre Buchung!
              </p>
    

</body>

</html>