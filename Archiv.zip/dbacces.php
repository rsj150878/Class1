<?php
//database connect
$dbname = "bwi";
$user = "bwiuser";
$password = "LVwbf2005%";
$host = "localhost";
$port = "3307";
